const DoctorsDetails = () => {
  return <div>DoctorsDetails</div>;
};

export default DoctorsDetails;
