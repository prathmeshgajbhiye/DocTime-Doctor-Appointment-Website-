const Doctors = () => {
  return <div>Doctors</div>;
};

export default Doctors;
